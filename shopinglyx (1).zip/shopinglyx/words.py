v="Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa, aliquam cumque dicta atque gg"
num=0
for i in v:
    num+=1
print(num)